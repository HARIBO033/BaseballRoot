package com.baseball_root;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaseballRootApplicationTests {

	@Test
	void contextLoads() {
	}

}
