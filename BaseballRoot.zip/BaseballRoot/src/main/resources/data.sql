insert into member (age, id, name, nickname, profile_photo, gender, member_code)
values (3, 1, 'lee', 'nick', 'profilePhoto', 'male', 'memberCode');
insert into member (age, id, name, nickname, profile_photo, gender, member_code)
values (5, 2, 'kim', 'hari', 'profilePhoto', 'male', 'memberCode');
insert into member (age, id, name, nickname, profile_photo, gender, member_code)
values (5, 3, 'park', 'coco', 'profilePhoto', 'male', 'memberCode');
insert into member (age, id, name, nickname, profile_photo, gender, member_code)
values (5, 4, 'kim', 'momo', 'profilePhoto', 'male', 'memberCode');

/*insert into diary (id,image_url, home_vs_away, place, seat, title, content, line_up, mvp, member_nickname, created_at, updated_at)
values (1,'imageUrl', 'homeVsAway', 'place', 'seat', 'title', 'content', 'lineUp', 'mvp', 123, '2021-07-01 00:00:00',
        '2021-07-01 00:00:00');*/